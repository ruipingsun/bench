#include "fileio.h"
/* 
 * Define G v
 */ 

/* buff */ 
char *read_buf; 
unsigned char *write_buf; 
/* update  sleep time */ 
unsigned int update_sleep_source_time ;
/* Delay sleep time */ 
unsigned int  delay_sleep_source_time  ;
/*  Timing V */ 
struct timezone get_timezone ;
struct timeval  get_timeval_before,get_timeval_after  ;
unsigned int diff_sec , diff_msec ;

/* Random seed */ 
unsigned int random_seed ;
struct timezone random_timezone ;
struct timeval  random_timeval  ;
int    random_pseudo_buf[MAX_TOTAL_RUN*2];
int    random_pseudo_total   ; 
int    random_pseudo_current ; 


/* 
 * Major parameters  
 */ 
char file_path[512]; 
unsigned int storage_type ; 
unsigned int act ; 
unsigned int act_m; 
long  file_size ; 
unsigned int block_size; 
unsigned int total_run ; 

/*  dd random debugging */ 

#define	DD_DEBUGGING	0    
#define	DD_CHECK_BIG	231	
#define	DD_CHECK_PP 	50000

unsigned long  total_dd_random=0 ; 
unsigned long  total_dd_random_big=0 ; 

/*
 ***************************************************
 * Function name: report_all 
 * 	Arg: 
 *	Return: 
 *		int: 
 *			 1: OK 
 *			-1: Error  
 *		
 ***************************************************
 */ 
int report_all(total_sec, total_msec) 
int total_sec;
int total_msec;
{
double tt_time_sec, tt_time_nodelay_sec, tt_time_msec, tt_time_nodelay_msec; 
double tt_bytes_m,tt_bytes;     
double thr_m, thr_m_nodelay, latency ; 
double iops; 

/*
 *Caculate all number 
 */


tt_time_msec = (double) total_sec*1000000.0  + (double) total_msec ; 
tt_time_nodelay_msec  = tt_time_msec - (double) total_run * ((double) update_sleep_source_time + (double) delay_sleep_source_time);
tt_time_sec = tt_time_msec/(double)1000000.0 ; 
tt_time_nodelay_sec = tt_time_nodelay_msec/(double)1000000.0 ; 

if ( act == ACT_UPDATE) 
	{
	tt_bytes = (double ) total_run * (double)block_size  * 2.0 ; 
	tt_bytes_m = tt_bytes/(1024.0*1024.0); 
	thr_m = tt_bytes_m /tt_time_sec ; 
	thr_m_nodelay = tt_bytes_m/tt_time_nodelay_sec ; 
	latency  = tt_time_nodelay_msec/(double)total_run ; 
	iops = (total_run/tt_time_nodelay_sec) * 2.0; 
	}
else 
	{
	tt_bytes = (double ) total_run * (double)block_size ; 
	tt_bytes_m = tt_bytes/(1024.0*1024.0); 
	thr_m = tt_bytes_m /tt_time_sec ; 
	thr_m_nodelay = tt_bytes_m/tt_time_nodelay_sec ; 
	latency  = tt_time_nodelay_msec/(double)total_run ; 
	iops = total_run/tt_time_nodelay_sec; 
	} 

/*
 * Part1: 
 *	Report Test Info: what is running 
 */ 

		printf(" ===========Test info========= \n") ; 

switch (act)
	{ 
	case ACT_READ:
		printf("   Action:Read "); 
		break; 
	case ACT_WRITE:
		printf("   Action:Write "); 
		break; 
	case ACT_UPDATE:
		printf("   Action:Update "); 
		break; 
	default: 
		break; 
	} 

switch (act_m)
	{ 
	case ACT_M_RANDOM:
		printf(" Random\n"); 
		break; 
	case ACT_M_SEQ:
		printf(" Sequential\n"); 
		break; 
	default: 
		break; 
	} 

		printf("    Block size:%d \n",block_size); 
		printf("    Total  run :%d \n",total_run); 
		printf("    Delay bewteen each run:%d (Micro Sec) \n",delay_sleep_source_time); 
		printf("    Delay bewteen each read and write:%d (Micro Sec) \n",update_sleep_source_time); 

/*
 * Part2: 
 *	Report Summary 
 */ 

		printf(" ===========Result Summary==== \n") ; 

		printf("    Throughput (including delay):%4.3f (M/sec)\n",thr_m); 
		printf("    Throughput (excluding delay):%4.3f (M/sec)\n",thr_m_nodelay); 
		printf("    IOPS       (excluding delay):%4.3f (IO/sec)\n",iops); 
		printf("    Total IO  = %6.3f (M) \n", tt_bytes_m); 
		printf("    Total time (including delay):%4.3f(sec)\n",tt_time_sec); 
		printf("    Total time (excluding delay):%4.3f(sec)\n",tt_time_nodelay_sec); 
switch (act)
	{ 
	case ACT_READ:
		printf("    Avg latency (1 Read, in Micro Sec)%7.3f\n",latency); 
		break; 
	case ACT_WRITE:
		printf("    Avg latency (1 Write in Micro Sec)%7.3f\n",latency); 
		break; 
	case ACT_UPDATE:
		printf("    Avg latency (1 Read + 1 Write, in Micro Sec)%7.3f\n",latency); 
		break; 
	default: 
		break; 
	} 
/*
 * Part 3:
 *     Compressed report
 */
	printf("TTT %4.3f %4.3f %7.3f\n",thr_m_nodelay,iops,latency); 

return(1); 

}/*End of report_all() */ 
/*
 *****************************************************
 * Function: random_utl
 *      Arguments:
 *              int start_r
 *              int end_r
 *              unsigned int *random_seed
 *      return:  int :  number between start_r and end_r
 *      Note: ideal seed is tv_usec in timeval
 *      Note: !!! to achieve AVG=N : start_r = 0 , end_r = N+1
 *****************************************************
 */
int random_utl(start_r, end_r, random_seed)
int start_r ;
int end_r ;
unsigned int *random_seed ;
{
int re ;
int rang ;
int rr   ;

rang = end_r - start_r ;
re = rand()  ; 
/* re = rand_r(random_seed) ; */ 
/* rr = (int ) *random_seed; */
rr = (int ) re ; 


if ( rr  < 0 )
        rr = -rr ;


return(start_r + rr%rang) ;

}/* End of random_utl () */
/*
 *****************************************************
 * Function: random_
 *      Arguments:
 *****************************************************
 */
void random_pseudo_init(random_seed,total_block)  
unsigned int *random_seed ;
unsigned int total_block; 
{
int i,j,r_num, tmp_total ; 

tmp_total = total_block*2 ; 

for ( i = 0 ; i < tmp_total ; i++ ) 
	random_pseudo_buf[i] = -1 ; 

random_pseudo_total   = total_block ;   
random_pseudo_current = 0;  

for ( i = 0 ; i < total_block ; i++ ) 
	{ 
	r_num = random_utl(0,tmp_total,&random_seed); 
	while (random_pseudo_buf[r_num] != -1) 
		{ 
		r_num = (r_num + 1) % tmp_total ; 
		} 
	random_pseudo_buf[r_num] = i ; 
	} 

/*
 * Merging the array into 1 size 
 */ 
j = total_block;
for ( i = 0 ; i < total_block ; i++ ) 
	{ 
	if (random_pseudo_buf[i] == -1) 
		{ 
		while (random_pseudo_buf[j] == -1 ) 
			{ 
			j = j + 1 ; 
			} 
		random_pseudo_buf[i]= random_pseudo_buf[j] ;  
		j = j + 1 ; 
		} 
	} 
} /* End of random_pseudo_init() */
/*
 *****************************************************
 * Function: random_pseudo_next
 *      Arguments:NONE 
 *	Return: a pseudo number within total blocks 
 *****************************************************
 */
unsigned random_pseudo_next()
{
if ( random_pseudo_current <  random_pseudo_total ) 
	{
	random_pseudo_current ++ ;
	return (random_pseudo_buf[random_pseudo_current-1]);
	} 
else 
	return (0) ; 

} /* End of random_pseudo_next() */ 

/*
 ***************************************************
 * Function name: init_data
 * 	Arg: 
 *		char *inbufp 
 *		int inbuf_size 
 *	Return: 
 *		int: 
 *			 1: OK 
 *			-1: Error  
 *		
 *     Note: 
 *	Now: sequncial number 
 *	Ruiping add real random number here
 *	
 ***************************************************
 */ 
int init_data(inbufp, inbuf_size) 
char inbufp[] ; 
int inbuf_size; 
{
int i,j ; 

j=0  ; 

for ( i = 0 ; i  < inbuf_size ; i++ ) 
	{
	inbufp[i] = (char)j ; 
	j = (j+1)%256; 
	} 

return(1); 
}/*End of init_data() */ 


/*
 ***************************************************
 * Function name: dd_random_data 
 * 	Arg: 
 *		char *inbufp 
 *		int inbuf_size 
 *	Return: 
 *		int: 
 *			 1: OK 
 *			-1: Error  
 *		
 *     Note: 
 *		generate true random number evary call 
 *		
 ***************************************************
 */ 
int dd_random_data(inbufp, inbuf_size) 
unsigned char inbufp[] ; 
int inbuf_size; 
{
int i,j ; 
unsigned long  rr  ; 
struct timezone get_timezone ;
struct timeval  get_timeval  ;
double rate, rate_p ; 



for ( i = 0 ; i  < inbuf_size ; i++ ) 
        {
	if (i%128 == 0 ) 
		{ 
		gettimeofday( &get_timeval, &get_timezone) ;
		rr= (unsigned long ) get_timeval.tv_usec;
		rr = rr%99971 ; 
		} 


	inbufp[i] =  (unsigned char ) rr%256 ; 

	total_dd_random ++ ; 
	if ( DD_DEBUGGING == 1 ) 
		{ 
		if ( inbufp[i] == DD_CHECK_BIG ) 
			{ 
			total_dd_random_big ++ ; 
			rate=(double ) total_dd_random_big/ (double ) total_dd_random   ; 
			rate_p= (double ) 1.0 / rate ; 

			if ( total_dd_random_big%DD_CHECK_PP == 0 ) 
				{ 
				printf("total=%lld,big=%lld, rate=%1.6f , rate_p=%4.3f \n", 
					total_dd_random, total_dd_random_big, rate, rate_p ) ; 
				}
			} 
		}
	rr = (rr * rr) % 99971;  
        }

return(1); 
}/*End of dd_random_data() */ 


/*
 *********************************************88
 * Function: mysleep
 * 	Input: Microsec 
 * 	Return: 0 
 *********************************************88
 */

int mysleep(microsec) 
unsigned int microsec ; 
{
unsigned int i, j, k ; 

k = microsec * CPU_CALIBRATION  ;  /* Calibrition */ 

for (i = 0 ; i < k ; i++ )
        {
        j = i ;
        }
return(0) ;

}/* End of mysleep() */


/*
 ***************************************************
 * Function name: open_file 
 * 	Arg: 
 *	Return: 
 *		int: 
 *			 >=0 :fd 
 *			-1: Error  
 *	Notes: Ruiping: do not support Block  yet 
 *		write and seq  ==> append 0 file 
 *			file exist: truncate 
 *			file does not exist: create 
 ***************************************************
 */ 
int  open_file(file_path, storage_type,action,action_m) 
char *file_path ; 
int  storage_type; 
int action ;
int action_m; 
{
int fd; 
mode_t  mode ; 

switch ( storage_type) 
	{ 
	case STORAGE_FS:  /* Netapp NAS */ 
		switch (action)
			{ 
			case ACT_READ: 
				fd = open( file_path,O_RDONLY|O_SYNC|O_DIRECT); 
				break; 
			case ACT_WRITE:
				if ( action_m == ACT_M_RANDOM ) 
					{
					fd = open( file_path,O_WRONLY|O_SYNC|O_DIRECT); 
					} 
				else 
					{
					mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
					fd = open(file_path, O_WRONLY | O_CREAT | O_TRUNC|O_SYNC|O_DIRECT, mode);
					} 
				break; 
			case ACT_UPDATE: 
				fd = open( file_path,O_RDWR|O_SYNC|O_DIRECT); 
				break; 
			default: 
				break ; 
			} 
		break; 
	case STORAGE_BLOCK:  /* EMC DMX or CX */ 
		switch (action)
			{ 
			case ACT_READ: 
				fd = open( file_path,O_RDONLY|O_SYNC|O_DIRECT); 
				break; 
			case ACT_WRITE:
				fd = open( file_path,O_WRONLY|O_SYNC|O_DIRECT); 
				break; 
			case ACT_UPDATE: 
				fd = open( file_path,O_RDWR|O_SYNC|O_DIRECT); 
				break; 
			default: 
				break ; 
			} 

		break;  
	default: 
		break; 
	} 

if ( fd >=0 ) 
	return(fd); 
else 
	return(-1); 

}/*End of open_file() */ 

/*
 *********************************************************************************
 * 
 *	main:   
 *	  usage: fileio PATH S_TYPE ACT ACT_M FILE_ZIE BLOCK_SZE TOTAL_RUN DELAY_P DELAY_U 
 *	  example: 
 *		./fileio ./DATA/file1 F R S 409600 1024 1000 0 0  
 *********************************************************************************
 */
int main (argc,argv) 
int argc; 
char *argv[];
{ 
int i,j; 
int fd; 
off_t file_offset ; 
unsigned int r_num   ; 
unsigned int total_block ; 

/*
 * Read parameter:
 */	
if ( argc != 10) 
	{ 
	printf("Usage: %s PATH S_TYPE ACT ACT_M FILE_ZIE BLOCK_SZE TOTAL_RUN DELAY_P DELAY_U  \n",argv[0]); 
	exit (1); 
	} 

strncpy(file_path, argv[1],256); 
file_size  = atol(argv[5]); 
block_size = atoi(argv[6]); 
total_run  = atoi(argv[7]); 
delay_sleep_source_time = atoi(argv[8]); 
update_sleep_source_time = atoi(argv[9]); 

switch (argv[2][0]) 
	{ 
	case 'B': 
		storage_type = STORAGE_BLOCK;  
		break; 
	case 'F': 
		storage_type = STORAGE_FS;
		break; 
	default: 
		printf("Error Storage type : B|F \n"); 
		exit(1); 
	}; 

switch (argv[3][0]) 
	{ 
	case 'R': 
		act=ACT_READ; 
		break; 
	case 'W': 
		act=ACT_WRITE; 
		break; 
	case 'U': 
		act=ACT_UPDATE; 
		break; 
	default: 
		printf("Error act  : R|W|U \n"); 
		exit(1); 
	}; 

switch (argv[4][0]) 
	{ 
	case 'R': 
		act_m=ACT_M_RANDOM; 
		break; 
	case 'S': 
		act_m=ACT_M_SEQ; 
		break; 
	default: 
		printf("Error act mode   : R|S \n"); 
		exit(1); 
	}; 

/* Check max runs */ 

i = MAX_TOTAL_RUN; 
if (( total_run   > i ) &&  (act_m == ACT_M_RANDOM ) ) 
	{ 
	printf("Total run must less than %d for random operations\n", i) ; 
	exit(1) ; 
	} ; 

/*
 * Init 
 * 	allocate aligned memory  for both read and write buffer 
 *	Total_block 
 *	Random seed 
 *	write buff 
 */ 

/* Allocate aligned memory */
 
if (posix_memalign(&read_buf, 4096, MAX_BUF_SIZE) != 0) 
	{ 
	printf("Error: posix_memalign  \n");  
	exit(1); 
	}   

if (posix_memalign(&write_buf, 4096, MAX_BUF_SIZE) != 0) 
	{ 
	printf("Error: posix_memalign  \n");  
	exit(1); 
	}   

/* Total block */ 

total_block = file_size/(long) block_size ; 

/* Init random_seed */

gettimeofday( &random_timeval, &random_timezone) ;
random_seed = (unsigned int)random_timeval.tv_usec ;

srand(random_seed) ;   

if (act_m == ACT_M_RANDOM ) 
	{ 
	if (PSEUDO_RANDOM_FLAG == 1) 
		random_pseudo_init(&random_seed,total_block); 
	}

if ( init_data(write_buf,block_size) != 1) 
	{ 
	printf("Error: init_data \n");  
	exit(1); 
	}  
/*
 * Open file 
 */ 
if ((fd= open_file(file_path, storage_type,act,act_m)) < 0) 
	{ 
	printf("Error open file=%s\n",file_path); 
	exit(1); 
	}   
/*
 *Major loop 
 * Start timing 
 *	Loop (total run) 
 *		action 
 *		delay 
 *	End loop 
 */ 

/*  Get current time */ 
if ( gettimeofday( &get_timeval_before, &get_timezone) != 0)
        {
        printf("Error: Get time \n") ;
	exit(1);
	} 
/* Major action loop */

for ( i = 0 ; i < total_run; i++ ) 
	{ 
/*
 * Step1: Seek if it is needed 
 * Step2: Read or Write or update ( Read + delay + seek backup + write)
 * Step3: delay 
 */ 

	if (act_m == ACT_M_RANDOM ) 
		{ 
		if (PSEUDO_RANDOM_FLAG == 1) 
			r_num = random_pseudo_next(); 
		else 
			r_num = random_utl(0, total_block ,&random_seed); 

		file_offset = (off_t) r_num * (off_t) block_size ; 

		if (lseek(fd,file_offset, SEEK_SET ) != file_offset)
			{
        		printf("Error seek file\n");
			exit(1);
			} 
		}

	switch (act) 
		{ 
		case ACT_READ:  
			if ( (j = read (fd,read_buf,block_size)) != block_size)  	  
				{ 
        			printf("Error read file\n");
				exit(1);
				} 
			break ; 
		case ACT_WRITE: 

			dd_random_data (write_buf,block_size) ; 

			if ( (j = write (fd,write_buf,block_size)) != block_size)  	  
				{ 
        			printf("Error write file\n");
				exit(1);
				} 
			break ; 
		case ACT_UPDATE:
			if ( (j = read (fd,read_buf,block_size)) != block_size)  	  
				{ 
        			printf("Error read file\n");
				exit(1);
				} 
			if (update_sleep_source_time > 0)
               			{
               			if ( mysleep(update_sleep_source_time)  != 0 )
                 			{
                      			printf("Error: nsleep \n");
                      			exit(1);
					} 
				} 

			file_offset = (off_t) (-1) * (off_t) block_size ; 
			if (lseek(fd,file_offset, SEEK_CUR ) < 0 )
				{
        			printf("Error seek file\n");
				exit(1);
				} 
			if ( (j = write (fd,write_buf,block_size)) != block_size)  	  
				{ 
        			printf("Error write file\n");
				exit(1);
				} 
			break ; 
		default: 
			break ; 
		}; 
	if (delay_sleep_source_time > 0)
               	{
               	if ( mysleep(delay_sleep_source_time)  != 0 )
                 	{
                      	printf("Error: nsleep \n");
                      	exit(1);
			} 
		} 

	}  
		
/* Get after time, must close file first  */ 

close (fd) ; 
if ( gettimeofday( &get_timeval_after, &get_timezone) != 0)
        {
        printf("Error: get time \n") ;
        exit(1);
        }
/* 
 *caculate time diff 
 */ 
diff_sec = (unsigned int) get_timeval_after.tv_sec - (unsigned int) get_timeval_before.tv_sec ;

if ((unsigned int)get_timeval_after.tv_usec > (unsigned int) get_timeval_before.tv_usec)
      	diff_msec = (unsigned int) get_timeval_after.tv_usec - (unsigned int) get_timeval_before.tv_usec ;
else
	{
        diff_sec -- ;
        diff_msec = ((unsigned int) 1000000 - (unsigned int) get_timeval_before.tv_usec) + (unsigned int) get_timeval_after.tv_usec ;
        }
/* 
 *Rporing 
 */ 
if (( i= report_all(diff_sec,diff_msec)) != 1) 
	{ 
	printf("Error report_all \n"); 
	exit(1); 
	}  
/*
 * End 
 */ 
exit (0);  
}/* End of main() */ 
