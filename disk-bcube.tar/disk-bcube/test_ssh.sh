#!/bin/ksh 

let i=0

while (( i < 1000000 )) ; do 

ssh sruiping@dba-server4.stg.test.sp2.yahoo.com ls  > /dev/null  & 


let j=i%4 

if (( j==1 )) then  
sleep 1 
fi 

let i=i+1 
echo $i

done 


