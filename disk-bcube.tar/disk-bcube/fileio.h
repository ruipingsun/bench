#define _LARGEFILE64_SOURCE
#define _LARGEFILE_SOURCE 
#include <stdio.h> 
#include <sys/types.h> 
#include <math.h>
#include <sys/time.h>
#include <stdlib.h>  
#define _POSIX_C_SOURCE 199309
#include <unistd.h> 
#include <sys/stat.h>
#include <asm-x86_64/fcntl.h>




#define MAX_BUF_SIZE	4194304 /* 4M */ 
/* MAX_TOTAL_RUN	16777216 so max total size is about 128G for 8k block ==> will allocate 128M memory  */ 
#define MAX_TOTAL_RUN	4194304  /* so max total size is about 32G for 8k block ==> will allocate 32 M memory   */ 


#define CPU_CALIBRATION       		322   /* AMD Opteron (tm) Processor 852, CPU 2.6G */  

/* 
 * For act
 */ 
#define ACT_READ		1
#define ACT_WRITE		2

/*
 * For act mode 
 */ 

#define ACT_M_RANDOM		1 
#define ACT_M_SEQ		2 

/*
 * For storage type
 */ 

#define STORAGE_BLOCK		1
#define STORAGE_FS   		2

