#include "fileio.h"
/* 
 * Define G v
 */ 

/* buff */ 
char *read_buf; 
char *write_buf; 
/* update  sleep time */ 
unsigned int update_sleep_source_time ;
/* Delay sleep time */ 
unsigned int  delay_sleep_source_time  ;
/*  Timing V */ 
struct timezone get_timezone ;
struct timeval  get_timeval_before,get_timeval_after  ;
unsigned int diff_sec , diff_msec ;

/* Random seed */ 
unsigned int random_seed ;
struct timezone random_timezone ;
struct timeval  random_timeval  ;
int    random_pseudo_buf[MAX_TOTAL_RUN*2];
unsigned int    random_pseudo_total   ; 
unsigned int    random_pseudo_current ; 


/* 
 * Major parameters  
 */ 
char file_path[512]; 
unsigned int storage_type ; 
unsigned int act ; 
unsigned int act_m; 
long  file_size ; 
unsigned int block_size; 
unsigned int total_run ; 

/*
 ***************************************************
 * Function name: report_all 
 * 	Arg: 
 *	Return: 
 *		int: 
 *			 1: OK 
 *			-1: Error  
 *		
 ***************************************************
 */ 
int report_all(total_sec, total_msec) 
int total_sec;
int total_msec;
{
double tt_time_sec, tt_time_msec ; 
double tt_bytes_m,tt_bytes;     
double thr_m, latency ; 
double iops; 

/*
 *Caculate all number 
 */

tt_time_msec = (double) total_sec*1000000.0  + (double) total_msec ; 
tt_time_sec = tt_time_msec/(double)1000000.0 ; 

tt_bytes = (double ) total_run * (double)block_size ; 
tt_bytes_m = tt_bytes/ (double ) (1024.0*1024.0); 

thr_m = tt_bytes_m /tt_time_sec ; 
latency  = tt_time_msec/(double)total_run ; 
iops = (double ) total_run/tt_time_sec; 


/*
 * Printout      Compressed report
 */

printf("%11.2f %6.2f %6.2f %8.2f\n",tt_time_msec, iops,thr_m,latency); 

return(1); 
}/*End of report_all() */ 
/*
 *****************************************************
 * Function: random_utl
 *      Arguments:
 *              int start_r
 *              int end_r
 *              unsigned int *random_seed
 *      return:  int :  number between start_r and end_r
 *      Note: ideal seed is tv_usec in timeval
 *      Note: !!! to achieve AVG=N : start_r = 0 , end_r = N+1
 *****************************************************
 */
int random_utl(start_r, end_r, random_seed)
int start_r ;
int end_r ;
unsigned int *random_seed ;
{
int re ;
int rang ;
int rr   ;

rang = end_r - start_r ;
re = rand()  ; 
/* re = rand_r(random_seed) ; */ 
/* rr = (int ) *random_seed; */
rr = (int ) re ; 


if ( rr  < 0 )
        rr = -rr ;


return(start_r + rr%rang) ;

}/* End of random_utl () */
/*
 *****************************************************
 * Function: random_
 *      Arguments:
 *****************************************************
 */
void random_pseudo_init(random_seed,total_block)  
unsigned int *random_seed ;
unsigned int total_block; 
{
unsigned int i,j,r_num , tmp_total ; 

tmp_total = total_block*2 ; 

for ( i = 0 ; i < tmp_total ; i++ ) 
	random_pseudo_buf[i] = -1 ; 

random_pseudo_total   = total_block ;   
random_pseudo_current = 0;  

for ( i = 0 ; i < total_block ; i++ ) 
	{ 
	r_num = random_utl(0,tmp_total,&random_seed); 
	while (random_pseudo_buf[r_num] != -1) 
		{ 
		r_num = (r_num + 1) % tmp_total ; 
		} 
	random_pseudo_buf[r_num] = i ; 
	} 

/*
 * Merging the array into 1 size 
 */ 
j = total_block;
for ( i = 0 ; i < total_block ; i++ ) 
	{ 
	if (random_pseudo_buf[i] == -1) 
		{ 
		while (random_pseudo_buf[j] == -1 ) 
			{ 
			j = j + 1 ; 
			} 
		random_pseudo_buf[i]= random_pseudo_buf[j] ;  
		j = j + 1 ; 
		} 
	} 
} /* End of random_pseudo_init() */
/*
 *****************************************************
 * Function: random_pseudo_next
 *      Arguments:NONE 
 *	Return: a pseudo number within total blocks 
 *****************************************************
 */
unsigned random_pseudo_next()
{
if ( random_pseudo_current <  random_pseudo_total ) 
	{
	random_pseudo_current ++ ;
	return (random_pseudo_buf[random_pseudo_current-1]);
	} 
else 
	return (0) ; 

} /* End of random_pseudo_next() */ 
/*
 ***************************************************
 * Function name: init_data
 * 	Arg: 
 *		char *inbufp 
 *		int inbuf_size 
 *	Return: 
 *		int: 
 *			 1: OK 
 *			-1: Error  
 *		
 *     Note: 
 *	Now: sequncial number 
 *	Ruiping add real random number here
 *	
 ***************************************************
 */ 
int init_data(inbufp, inbuf_size) 
char inbufp[] ; 
unsigned int inbuf_size; 
{
int i,j ; 

j=0  ; 

for ( i = 0 ; i  < inbuf_size ; i++ ) 
	{
	inbufp[i] = (char)j ; 
	j = (j+1)%256; 
	} 

return(1); 
}/*End of init_data() */ 

/*
 *********************************************88
 * Function: mysleep
 * 	Input: Microsec 
 * 	Return: 0 
 *********************************************88
 */

int mysleep(microsec) 
unsigned int microsec ; 
{
unsigned int i, j, k ; 

k = microsec * CPU_CALIBRATION  ;  /* Calibrition */ 

for (i = 0 ; i < k ; i++ )
        {
        j = i ;
        }
return(0) ;

}/* End of mysleep() */

/*
 ***************************************************
 * Function name: open_file 
 * 	Arg: 
 *	Return: 
 *		int: 
 *			 >=0 :fd 
 *			-1: Error  
 *	Notes: Ruiping: do not support Block  yet 
 *		write and seq  ==> append 0 file 
 *			file exist: truncate 
 *			file does not exist: create 
 ***************************************************
 */ 
int  open_file(file_path, storage_type,action,action_m) 
char *file_path ; 
int  storage_type; 
int action ;
int action_m; 
{
int fd; 

switch ( storage_type) 
	{ 
	case STORAGE_FS:  /* Netapp NAS */ 
		switch (action)
			{ 
			case ACT_READ: 
				fd = open( file_path,O_RDONLY|O_SYNC|O_DIRECT); 
				break; 
			case ACT_WRITE:
				fd = open( file_path,O_WRONLY|O_SYNC|O_DIRECT); 
				break; 
			default: 
				break ; 
			} 
		break; 
	case STORAGE_BLOCK:  /* EMC DMX or CX */ 
		switch (action)
			{ 
			case ACT_READ: 
				fd = open( file_path,O_RDONLY|O_SYNC|O_DIRECT); 
				break; 
			case ACT_WRITE:
				fd = open( file_path,O_WRONLY|O_SYNC|O_DIRECT); 
				break; 
			default: 
				break ; 
			} 

		break;  
	default: 
		break; 
	} 

if ( fd >=0 ) 
	return(fd); 
else 
	return(-1); 

}/*End of open_file() */ 

/*
 *********************************************************************************
 * 
 *	main:   
 *	  usage: fileio PATH OFFSET  S_TYPE ACT ACT_M FILE_ZIE BLOCK_SZE TOTAL_RUN SLEEP_SEC  SLEEP_NANO_SEC
 *	  example: 
 *		./fileio ./DATA/file1 1024 F R S 409600 4 1000  9000
 *		all size in k (1024) 
 *********************************************************************************
 */
int main (argc,argv) 
int argc; 
char *argv[];
{ 
unsigned int i,j; 
int fd; 
off64_t file_offset ;  
off64_t file_begin_offset ; 
unsigned int r_num   ; 
unsigned int total_block ; 
unsigned int true_random_flag  ; 

struct timespec sleep_req , sleep_remain; 

/*
 * Read parameter:
 */	
if ( argc != 11) 
	{ 
	printf("Usage: %s PATH OFFSET  S_TYPE ACT ACT_M FILE_ZIE BLOCK_SZE TOTAL_RUN SLEEP_SEC SLEEP_NANO_SEC \n",argv[0]); 
	exit (1); 
	} 

strncpy(file_path, argv[1],256); 
file_begin_offset = (off64_t )atol(argv[2]) * (off64_t)  1024 ; 
file_size  = atol(argv[6]) * (long) 1024 ; 
block_size = atoi(argv[7]) * 1024 ; 
total_run  = atoi(argv[8]); 
sleep_req.tv_sec   = atoi(argv[9]) ; 
sleep_req.tv_nsec  = atol(argv[10]); 

switch (argv[3][0]) 
	{ 
	case 'B': 
		storage_type = STORAGE_BLOCK;  
		break; 
	case 'F': 
		storage_type = STORAGE_FS;
		break; 
	default: 
		printf("Error Storage type : B|F \n"); 
		exit(1); 
	}; 

switch (argv[4][0]) 
	{ 
	case 'R': 
		act=ACT_READ; 
		break; 
	case 'W': 
		act=ACT_WRITE; 
		break; 
	default: 
		printf("Error act  : R|W\n"); 
		exit(1); 
	}; 

switch (argv[5][0]) 
	{ 
	case 'R': 
		act_m=ACT_M_RANDOM; 
		break; 
	case 'S': 
		act_m=ACT_M_SEQ; 
		break; 
	default: 
		printf("Error act mode   : R|S \n"); 
		exit(1); 
	}; 

/* 
 * check total_block againt total_run 
 *	if = ==> no repeat random 
 * 	else  ==> true random 
 */ 

total_block = file_size/block_size ; 


if ( total_block ==  total_run ) 
	true_random_flag  = 0 ; 
else  
	true_random_flag  = 1 ; 

if (true_random_flag  != 1 ) 
	{  
/* Check max runs */ 
	i = MAX_TOTAL_RUN; 
	if (( total_run   > i ) &&  (act_m == ACT_M_RANDOM ) ) 
		{ 
		printf("Total run must less than %d for random operations\n", i) ; 
		exit(1) ; 
		} ; 
	} 

/*
 * Init 
 * 	allocate aligned memory  for both read and write buffer 
 *	Random seed 
 *	write buff 
 */ 

/* Allocate aligned memory */
 
if (posix_memalign(&read_buf, 4096, MAX_BUF_SIZE) != 0) 
	{ 
	printf("Error: posix_memalign  \n");  
	exit(1); 
	}   

if (posix_memalign(&write_buf, 4096, MAX_BUF_SIZE) != 0) 
	{ 
	printf("Error: posix_memalign  \n");  
	exit(1); 
	}   



/* Init random_seed */

gettimeofday( &random_timeval, &random_timezone) ;
random_seed = (unsigned int)random_timeval.tv_usec ;

srand(random_seed) ;   


if (act_m == ACT_M_RANDOM ) 
	{ 
	if (true_random_flag  != 1) 
		random_pseudo_init(&random_seed,total_block); 
	}

if ( init_data(write_buf,block_size) != 1) 
	{ 
	printf("Error: init_data \n");  
	exit(1); 
	}  
/*
 * Open file 
 */ 
if ((fd= open_file(file_path, storage_type,act,act_m)) < 0) 
	{ 
	printf("Error open file=%s\n",file_path); 
	exit(1); 
	}   

/*
 * Seek to the first position
 */ 

file_offset =  (off64_t ) file_begin_offset  ; 
if (lseek64(fd,file_offset, SEEK_SET ) != file_offset)
	{
       	printf("Error seek file\n");
	exit(1);
	} 

/*
 * Sleep before run 
 */ 

i = nanosleep(&sleep_req,&sleep_remain) ;  

if ( i != 0) 
	{ 
	printf("can not sleep nanosleep \n"); 
	exit (1); 
	}  

/*
 *Major loop 
 * Start timing 
 *	Loop (total run) 
 *		action 
 *		delay 
 *	End loop 
 */ 

/*  Get current time */ 
if ( gettimeofday( &get_timeval_before, &get_timezone) != 0)
        {
        printf("Error: Get time \n") ;
	exit(1);
	} 
/* Major action loop */

for ( i = 0 ; i < total_run; i++ ) 
	{ 
/*
 * Step1: Seek if it is needed 
 * Step2: Read or Write or update ( Read + delay + seek backup + write)
 * Step3: delay 
 */ 
	if (act_m == ACT_M_RANDOM ) 
		{ 
		if (true_random_flag != 1) 
			r_num = random_pseudo_next(); 
		else 
			r_num = random_utl(0, total_block ,&random_seed); 

		file_offset = (off64_t ) file_begin_offset + (off64_t) r_num * (off64_t) block_size;  
 
/*       		
 * Debuging 
			printf("file_offset=%10f, off-block=%10f\n",
			(double) file_offset , ((double) file_offset -  (double)  file_begin_offset) /(double) block_size );
 */ 

		if (lseek64(fd,file_offset, SEEK_SET ) != file_offset)
			{
        		printf("Error seek file\n");
			exit(1);
			} 
		}
	switch (act) 
		{ 
		case ACT_READ:  
			if ( (j = read (fd,read_buf,block_size)) != block_size) 
				{ 
        			printf("Error read file\n");
				exit(1);
				} 
			break ; 
		case ACT_WRITE: 
			if ( (j = write (fd,write_buf,block_size)) != block_size)  	  
				{ 
        			printf("Error write file\n");
				exit(1);
				} 
			break ; 
		default: 
			break ; 
		}; 

	}  
		
/* Get after time, must close file first  */ 

close (fd) ; 

if ( gettimeofday( &get_timeval_after, &get_timezone) != 0)
        {
        printf("Error: get time \n") ;
        exit(1);
        }
/* 
 *caculate time diff 
 */ 
diff_sec = (unsigned int) get_timeval_after.tv_sec - (unsigned int) get_timeval_before.tv_sec ;

if ((unsigned int)get_timeval_after.tv_usec > (unsigned int) get_timeval_before.tv_usec)
      	diff_msec = (unsigned int) get_timeval_after.tv_usec - (unsigned int) get_timeval_before.tv_usec ;
else
	{
        diff_sec -- ;
        diff_msec = ((unsigned int) 1000000 - (unsigned int) get_timeval_before.tv_usec) + (unsigned int) get_timeval_after.tv_usec ;
        }
/* 
 *Rporing 
 */ 
if (( i= report_all(diff_sec,diff_msec)) != 1) 
	{ 
	printf("Error report_all \n"); 
	exit(1); 
	}  
/*
 * End 
 */ 
exit (0);  
}/* End of main() */ 
